#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .supervised import Supervised
