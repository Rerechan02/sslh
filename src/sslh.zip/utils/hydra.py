#!/usr/bin/env python
# -*- coding: utf-8 -*-


def get_none(*args, **kwargs) -> None:
    return None
